﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Produttore_consumatore
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
           
        }
     //-------------------------------------------------NOTE----------------------------------------------------------------------------
        //RICORDARSI I CONTROLLI DI QUALUNQUE GENERE --> ANCHE PER CAMBIARE LA TABELLA
     //--------------------------------------------------------------------------------------------------------------------------------------
        
        private void txt_produttore_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar)) //bastava cambiare la funzione utilizzata
            {
              e.Handled = true;
              txt_produttore.Clear();
            }
            
            
        }

        private void btn_crea_Click(object sender, EventArgs e)
        {

            long number1 = 0;
            bool canConvert = long.TryParse(txt_produttore.Text, out number1);
            if (canConvert == true)
                return;
            else
            {
                MessageBox.Show("Errore.");
            }
        }
    }
}
